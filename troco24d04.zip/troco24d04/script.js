let valor1 = document.querySelector("#valor1");
let valor2 = document.querySelector("#valor2")
let botaoIgual = document.querySelector("#botaoIgual")
let resultado = document.querySelector("#resultado")

function subtrairNumeros(){
    let num1 = Number(valor1.value);
    let num2 = Number(valor2.value);

    let subtrairNumeros = num1 - num2;

    resultado.textContent = subtrairNumeros;
}
botaoIgual.onclick = function(){
    subtrairNumeros();
}