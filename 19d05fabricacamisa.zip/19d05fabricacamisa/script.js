let peque = document.querySelector("#peque");
let med = document.querySelector("#med");
let gran = document.querySelector("#gran");
let btcalculo = document.querySelector("#btcalculo");
let result = document.querySelector("#result");

function calcular(){
    let num1 = Number(peque.value);
    let num2 = Number(med.value);
    let num3 = Number(gran.value);

    c1alc = num1 * 10.00
    c2alc = num2 * 12.00
    c3alc = num3 * 15.00
    calc = c1alc + c2alc + c3alc;

    result.textContent = "R$"+calc;
}

btcalculo.onclick = function(){
    calcular();
}