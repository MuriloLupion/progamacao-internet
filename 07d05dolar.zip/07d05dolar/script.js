let campodolar = document.querySelector("#campodolar");
let btcalc = document.querySelector("#btcalc");
let porc1 = document.querySelector("#porc1");
let porc2 = document.querySelector("#porc2");
let porc5 = document.querySelector("#porc5");
let porc10 = document.querySelector("#porc10");
//segunda atividade
let numPessoas = document.querySelector("#numPessoas");
let btcalcovo = document.querySelector("#btcalcovo");
let ovos = document.querySelector("#ovos");
let queijo = document.querySelector("#queijo");
//terceira atividade
let prnuminteiro = document.querySelector("#prnuminteiro");
let segnuminteiro = document.querySelector("#segnuminteiro");
let btnuminte = document.querySelector("#btnuminte");
let soma = document.querySelector("#soma");
let sub = document.querySelector("#sub");
let mult = document.querySelector("#mult");
let divi = document.querySelector("#divi");
//quarta atividade
let sabor1 = document.querySelector("#sabor1");
let sabor2 = document.querySelector("#sabor2");
let sabor3 = document.querySelector("#sabor3");
let sabor4 = document.querySelector("#sabor4");
let refris = document.querySelector("#refris");
let sabores = document.querySelector("#btsabores");
let valorSabores = document.querySelector("#valorSabores");
let valorRefris = document.querySelector("#valorRefris");
let totalpizza = document.querySelector("#totalpizza");

function umPorcento(){
    let num1 = Number(campodolar.value);

    calc = num1 * 0.01;

    let umPorcento = num1 + calc;

    porc1.textContent = umPorcento;
}
btcalc.onclick = function(){
    umPorcento();
    doisPorcento();
    cincoPorcento();
    dezPorcento();
}
function doisPorcento(){
    let num1 = Number(campodolar.value);

    calc = num1 * 0.02;

    let doisPorcento = num1 + calc;

    porc2.textContent = doisPorcento;
}
function cincoPorcento(){
    let num1 = Number(campodolar.value);

    calc = num1 * 0.05;

    let cincoPorcento = num1 + calc;

    porc5.textContent = cincoPorcento;
}
function dezPorcento(){
    let num1 = Number(campodolar.value);

    calc = num1 * 0.1;

    let dezPorcento = num1 + calc;

    porc10.textContent = dezPorcento;
}
//segunda atividade
//2 ovos e 50 gramas por pessoas

function calcularOvos(){
    let num1 = Number(numPessoas.value);
    calc = num1 * 2;
    let calcularOvos = calc;
    ovos.textContent = calcularOvos;
}
btcalcovo.onclick = function(){
    calcularOvos();
    calcularQueijo();
}
function calcularQueijo(){
    let num1 = Number(numPessoas.value);
    let calcularQueijo = num1 * 50;
    queijo.textContent = calcularQueijo;
}
//terceira atividade

function somarNumeros(){
    let num1 = Number(prnuminteiro.value);
    let num2 = Number(segnuminteiro.value);
    
    somarNumeros = num1 + num2;
    soma.textContent = somarNumeros;
}
btnuminte.onclick = function(){
    somarNumeros();
    subtrairNumeros();
    multiplicarNumeros();
    divifirNumeros();
}
function subtrairNumeros(){
    let num1 = Number(prnuminteiro.value);
    let num2 = Number(segnuminteiro.value);
    
    subtrairNumeros = num1 - num2;
    sub.textContent = subtrairNumeros;
}
function multiplicarNumeros(){
    let num1 = Number(prnuminteiro.value);
    let num2 = Number(segnuminteiro.value);
    
    multiplicarNumeros = num1 * num2;
    mult.textContent = multiplicarNumeros;
}
function divifirNumeros(){
    let num1 = Number(prnuminteiro.value);
    let num2 = Number(segnuminteiro.value);
    
    divifirNumeros = num1 / num2;
    divi.textContent = divifirNumeros;
}
//quarta atividade
//sabor:R$12,00 refri:R$7,00
function calcularSabores() {
    let qntsabores = 0;

    const inputs = [sabor1, sabor2, sabor3, sabor4];

    for (let input of inputs) {
        if (input.value.trim() !== "") {
            qntsabores += 12;
        }
    }

    valorSabores.textContent = qntsabores;

    return qntsabores;
}

btsabores.onclick = function(){
    calcularSabores();
    calcularRefri();
    totalAmbos();
}
function calcularRefri(){
    let num1 = Number(refris.value);
    let calcrefris = num1 * 7;

    valorRefris.textContent = calcrefris;

    return calcrefris;
}

function totalAmbos() {
    let totalSabores = calcularSabores();
    let totalRefris = calcularRefri();
    let calctotal = totalSabores + totalRefris;

    totalpizza.textContent = calctotal;
}
