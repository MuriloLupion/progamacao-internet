let vlrreais = document.querySelector("#vlrreais");
let btreais = document.querySelector("#btreais");
let result = document.querySelector("#result");

function calculo(){
    let num1 = Number(vlrreais.value);
    let calc = num1 * 5.95;

    result.textContent = calc;
}

btreais.onclick = function(){
    calculo()
}