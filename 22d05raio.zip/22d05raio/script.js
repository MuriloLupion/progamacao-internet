let tmdpizz = document.querySelector("#tmdpizz");
let btt = document.querySelector("#btt");
let result = document.querySelector("#result");

function calcular(){
    let num1 = Number(tmdpizz.value);
    c1lc = num1 / 2;
    c2lc = c1lc * c1lc;

    result.textContent = c2lc;
}

btt.onclick = function(){
    calcular();
}