let valor1 = document.querySelector("#valor1");
let valor2 = document.querySelector("#valor2");
let valor3 = document.querySelector("#valor3");
let btCalculoarit = document.querySelector("#btCalculoarit");
let resultadoaritm = document.querySelector("#resultadoaritm");
let resultadopond = document.querySelector("#resultadopond");
let resultadomed = document.querySelector("#resultadomed");
let resultadomedmed = document.querySelector("#resultadomedmed");

function mediaAritmetica(){
    let num1 = Number(valor1.value);
    let num2 = Number(valor2.value);
    let num3 = Number(valor3.value);

    calc = num1 + num2 + num3;

    let mediaAritmetica = calc/3;

    resultadoaritm.textContent = mediaAritmetica;
    return mediaAritmetica;
}
btCalculoarit.onclick = function(){
    mediaAritmetica();
    mediaPonderada();
    somaMedias();
    mediaMedia();
}

function mediaPonderada(){
    let num1 = Number(valor1.value);
    let num2 = Number(valor2.value);
    let num3 = Number(valor3.value);
    
    calc = num1*3 + num2*2 + num3*5;
    calc2 = 3 + 2 + 5;

    let mediaPonderada = calc/calc2

    resultadopond.textContent = mediaPonderada;
    return mediaPonderada;
}

function somaMedias(){
    let media = (mediaPonderada()) + (mediaAritmetica());
    let mediamedia = media/2
    resultadomed.textContent = media;
    resultadomedmed.textContent = mediamedia;
    
}

