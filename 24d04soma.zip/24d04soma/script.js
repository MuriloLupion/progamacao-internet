let PrimeiroCampo = document.querySelector("#PrimeiroCampo");
let SegundoCampo = document.querySelector("#SegundoCampo");
let BotaoDeSoma = document.querySelector("#BotaoDeSoma");
let resultado = document.querySelector("#resultado");

function somarNumeros(){
    let PrimNumero = Number(PrimeiroCampo.value);
    let SegNumero = Number(SegundoCampo.value);

    let somarNumeros = PrimNumero + SegNumero;
        
    resultado.textContent = somarNumeros;
}
BotaoDeSoma.onclick = function(){
    somarNumeros();
}