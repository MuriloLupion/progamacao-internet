let nome = document.querySelector("#nome");
let idade = document.querySelector("#idade");
let btcalc = document.querySelector("#btcalc");
let result = document.querySelector("#result");
let piada = document.querySelector("#piada");

function somar(){
    let info1 = nome.value;
    let info2 = Number(idade.value);

    let calc = info2 * 365;

    result.textContent = info1+" voce possui "+calc+" de vida";
}

btcalc.onclick = function(){
    somar();
    tempoRestante();
}

function tempoRestante(){
    piada.textContent = "voce ainda possui 8 dias, aproveite bem";
}