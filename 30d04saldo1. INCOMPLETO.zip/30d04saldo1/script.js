let btSaldo = document.querySelector("#btSaldo");
let saldo = document.querySelector("#saldo");
let saldoDisp = document.querySelector("#saldoDisp");
let btDeSoma = document.querySelector("#btDeSoma");
let resultado = document.querySelector("#resultado");

function calcular(){
    let vlr1 = Number(saldoDisp.value);
    let vlrperc = 1/100*vlr1;
    let vlrcomperc = vlr1 + vlrperc;

    resultado.textContent = vlrcomperc;
}
btDeSoma.onclick = function(){
    calcular()
}