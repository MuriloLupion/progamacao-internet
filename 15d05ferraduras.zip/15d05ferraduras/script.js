let cavalos = document.querySelector("#cavalos");
let btcavalos = document.querySelector("#btcavalos");
let resultferrad = document.querySelector("#resultferrad");

function cavalosxFerraduras(){
    let num = Number(cavalos.value);
    
    qntd = num * 4;

    resultferrad.textContent = qntd+"ferraduras";
}

btcavalos.onclick = function(){
    cavalosxFerraduras();
}