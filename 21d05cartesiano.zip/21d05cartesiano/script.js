let vrl1x = document.querySelector("#vrl1x");
let vrl1y = document.querySelector("#vrl1y");
let vrl2x = document.querySelector("#vrl2x");
let vrl2y = document.querySelector("#vrl2y");
let btcalc = document.querySelector("#btcalc");
let result = document.querySelector("#result");

function calculo(){
    let num1x = Number(vrl1x.value);
    let num1y = Number(vrl1y.value);
    let num2x = Number(vrl2x.value);
    let num2y = Number(vrl2y.value);

    let c1alc = num2x - num1x;
    let c2alc = c1alc * c1alc;
    let c3alc = num2y - num1y;
    let c4alc = c3alc * c3alc;

    let c5alc = c2alc + c4alc;

    result.textContent = c5alc;
}

btcalc.onclick = function(){
    calculo();
}