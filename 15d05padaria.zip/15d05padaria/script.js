let paes = document.querySelector("#paes");
let broas = document.querySelector("#broas");
let btlucro = document.querySelector("#btlucro");
let resultlucros = document.querySelector("#resultlucros");

let btpoupanca = document.querySelector("#btpoupanca");
let resultpoupanca = document.querySelector("#resultpoupanca");

//paes:pãozinho custa R$ 0,12 e a broa custa R$ 1,50.
function calcularLucro(){
    let num1 = Number(paes.value);
    let num2 = Number(broas.value);
    let calc1 = num1 * 0.12;
    let calc2 = num2 * 1.50;
    let calc3 = calc1 + calc2;

    resultlucros.textContent = "R$"+calc3;

    return calc3;
}

btlucro.onclick = function(){
    calcularLucro();
}

//10%=0.1
function calcularPoupanca(){
    let vlr1 = calcularLucro();
    let soma = vlr1 * 0.1;
    let vlr2 = soma;

    resultpoupanca.textContent = "R$"+vlr2;
}

btpoupanca.onclick = function(){
    calcularPoupanca();
}