let vlrs = document.querySelector("#vlrs");
let btt = document.querySelector("#btt");
let anos = document.querySelector("#anos");
let meses = document.querySelector("#meses");
let dias = document.querySelector("#dias");

function calcularAnos(){
    let num = Number(vlrs.value);

    c1lc = num / 360;
    c2lc = num%360
    c3lc = c2lc%30

    anos.textContent = Math.floor (c1lc);

    dias.textContent = c3lc;
}

function calcularMeses(){
    let num = Number(vlrs.value);

    c1lc = num / 30;

    meses.textContent = Math.floor (c1lc);
}

btt.onclick = function(){
    calcularAnos();
    calcularMeses();
}