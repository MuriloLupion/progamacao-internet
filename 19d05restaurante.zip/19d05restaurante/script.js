let quilopr = document.querySelector("#quilopr");
let btquilo = document.querySelector("#btquilo");
let result = document.querySelector("#result");

function calcular(){
    let num1 = Number(quilopr.value);
    calc = num1 * 12;

    result.textContent = calc+" Quilos";
}

btquilo.onclick = function(){
    calcular();
}