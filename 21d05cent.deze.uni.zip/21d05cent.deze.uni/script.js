let vlr = document.querySelector("#vlr");
let btt = document.querySelector("#btt");
let cent = document.querySelector("#cent");
let deze = document.querySelector("#deze");
let uni = document.querySelector("#uni");

function calcularCentena(){
    let num1 =  Number(vlr.value.charAt(0));
    calc = num1;
    cent.textContent = calc+"00";
}

function calcularDezena(){
    let num1 =  Number(vlr.value.charAt(1));
    calc = num1;
    deze.textContent = calc+"0";
}

function calcularUnidade(){
    let num1 =  Number(vlr.value.charAt(2));
    calc = num1;
    uni.textContent = calc;
}

btt.onclick = function(){
    calcularCentena();
    calcularDezena();
    calcularUnidade();
}