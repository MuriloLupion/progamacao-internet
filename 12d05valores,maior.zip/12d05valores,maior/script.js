let valor1 = document.querySelector("#valor1");
let valor2 = document.querySelector("#valor2");
let bt2vlr = document.querySelector("#bt2vlr");
let resultado = document.querySelector("#resultado");
//segunda atividade
let valor3 = document.querySelector("#valor3");
let valor4 = document.querySelector("#valor4");
let valor5 = document.querySelector("#valor5");
let valor6 = document.querySelector("#valor6");
let bt4vlr = document.querySelector("#bt4vlr");
let resultAtv2 = document.querySelector("#resultAtv2");
//terceira atividade
let valorimparpar = document.querySelector("#valorimparpar");
let btimparpar = document.querySelector("#btimparpar");
let resultadoimparpar = document.querySelector("#resultadoimparpar");

function selecionarMaiorValor(){
    let num1 = Number(valor1.value);
    let num2 = Number(valor2.value);
    if(num1 > num2) {
        resultado.textContent = num1
    }
    else if (num2 > num1) {
        resultado.textContent = num2
    }
    else {
        resultado.textContent = "os valores são iguais"
    }
}

bt2vlr.onclick = function(){
    selecionarMaiorValor();
}

//segunda atividade

function menorValor(){
    let num3 = Number(valor3.value);
    let num4 = Number(valor4.value);
    let num5 = Number(valor5.value);
    let num6 = Number(valor6.value);
    if(num3<num4 && num3<num5 && num3<num6) {
        resultAtv2.textContent = num3
    }
    else if(num4<num3 && num4<num5 && num4<num6) {
        resultAtv2.textContent = num4
    }
    else if(num5<num3 && num5<num4 && num5<num6) {
        resultAtv2.textContent = num5
    }
    else if(num6<num3 && num6<num4 && num6<num5) {
        resultAtv2.textContent = num6
    }
    else{
        resultAtv2.textContent = "os valores são iguais"
    }
    
}

bt4vlr.onclick = function(){
    menorValor();
}
//terceira atividade

function determinarImparPar(){
    let num = Number(valorimparpar.value);
    if (num % 2 === 0) {
        num = "par"
    }
    else {
        num = "Impar"
    }
    resultadoimparpar.textContent = num
}

btimparpar.onclick = function(){
    determinarImparPar();
}
