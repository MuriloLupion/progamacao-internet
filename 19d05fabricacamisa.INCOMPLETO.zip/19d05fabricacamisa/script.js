let peque = document.querySelector("#peque");
let med = document.querySelector("#med");
let gran = document.querySelector("#gran");
let btcalculo = document.querySelector("#btcalculo");
let result = document.querySelector("#result");

function calcular(){
    let num1 = Number(peque.value);
    let num2 = Number(med.value);
    let num3 = Number(gran.value);

    num1 = 1 * 10.00
    num2 = 1 * 12.00
    num3 = 1 * 15.00
    calc = num1 + num2 + num3;

    result.textContent = "R$"+calc;
}

btcalculo.onclick = function(){
    calcular();
}