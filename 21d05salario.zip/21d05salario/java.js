let slrvlr = document.querySelector("#slrvlr");
let btt = document.querySelector("#btt");
let slrini = document.querySelector("#slrini");
let slrc15 = document.querySelector("#slrc15");
let slrf = document.querySelector("#slrf");

function salarioInicial(){
    let num1 = Number(slrvlr.value);
    slrini.textContent = num1;
}

function calcularAcrescimo(){
    let num1 = Number(slrvlr.value);
    calc = num1 * 0.15;
    c2lc = calc + num1;
    
    slrc15.textContent = c2lc;
}

function calcularDesconto(){
    let num1 = Number(slrvlr.value);
    calc = num1 * 0.08;
    c2lc = calc + num1;
    
    slrf.textContent = c2lc;
}

btt.onclick = function(){
    calcularAcrescimo();
    calcularDesconto();
    salarioInicial();
}