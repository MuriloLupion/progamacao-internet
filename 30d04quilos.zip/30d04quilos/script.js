let prdtquilo = document.querySelector("#prdtquilo");
let vquilo = document.querySelector("#vquilo");
let btDeSoma = document.querySelector("#btDeSoma");

function pesarQuilos(){
    let vlr1 = Number(prdtquilo.value);
    let vlr2 = Number(vquilo.value);

    let pesarQuilos = vlr1 * vlr2;

    resultado.textContent = pesarQuilos;
}
btDeSoma.onclick = function(){
    pesarQuilos();
}