let dia = document.querySelector("#dia");
let mes = document.querySelector("#mes");
let btdiames = document.querySelector("#btdiames");
let result = document.querySelector("#result");

function calculardia(){
    let num1 = Number(dia.value);
    let num2 = mes.value;
    if(num2==="janeiro"){ 
        num2=0
    }
    else if(num2==="fevereiro"){
        num2=30
    }
    else if(num2==="março"){
        num2=60
    }
    else if(num2==="abril"){
        num2=90
    }
    else if(num2==="maio"){
        num2=120
    }
    else if(num2==="junho"){
        num2=150
    }
    else if(num2==="julho"){
        num2=180
    }
    else if(num2==="agosto"){
        num2=210
    }
    else if(num2==="setembro"){
        num2=240
    }
    else if(num2==="outubro"){
        num2=270
    }
    else if(num2==="novembro"){
        num2=300
    }
    else if(num2==="dezembro"){
        num2=330
    }
    else {
        num2="coloque Um Mes valido"
    }
    
    calc = num1 + num2;
    
    
    result.textContent = calc;

}

btdiames.onclick = function(){
    calculardia();
}