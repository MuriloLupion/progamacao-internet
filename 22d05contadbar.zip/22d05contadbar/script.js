let vlr = document.querySelector("#vlr");
let btt = document.querySelector("#btt");
let r1esult = document.querySelector("#r1esult");
let r2esult = document.querySelector("#r2esult");
let r3esult = document.querySelector("#r3esult");

function calcular(){
    let num1 = Number(vlr.value);

    let calc = Math.floor(num1/3);
    let c1lc = Math.floor(calc);
    let c2lc = Math.floor(calc);

    let c3lc = (num1-(c1lc+c2lc));

    r1esult.textContent = "Carlos vai pagar "+c1lc;
    r2esult.textContent = "Andre vai pagar "+c2lc;
    r3esult.textContent = "Felipe vai pagar "+c3lc;
}

btt.onclick = function(){
    calcular();
}