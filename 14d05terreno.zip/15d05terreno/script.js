let largT1 = document.querySelector("#largT1");
let altuT1 = document.querySelector("#altuT1");
let btTerr1 = document.querySelector("#btTerr1");
let resultTerr1 = document.querySelector("#resultTerr1");
//terreno2
let largT2 = document.querySelector("#largT2");
let altuT2 = document.querySelector("altuT2");
let btt2 = document.querySelector ("#btt2")
let resultTerr2 = document.querySelector("#resultTerr2");

//terreno1

function areaTerreno1(){
    let larg = Number(largT1.value);
    let altu = Number(altuT1.value);
    
    let area = larg * altu;

    resultTerr1.textContent = area+"m²";
}

btTerr1.onclick = function(){
    areaTerreno1();
    terrenoArea2()
    
}

//terreno2

function terrenoArea2(){
    resultTerr2.textContent = "test"
}


btt2.onclick = function (){
    terrenoArea2();
} 