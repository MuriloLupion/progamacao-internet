let largT1 = document.querySelector("#largT1");
let altuT1 = document.querySelector("#altuT1");
let btTerr1 = document.querySelector("#btTerr1");
let resultTerr1 = document.querySelector("#resultTerr1");
//terreno2
let larT2 = document.querySelector("#larT2");
let altT2 = document.querySelector("#altT2");
let btTrr2 = document.querySelector("#btTrr2");
let resulTerr2 = document.querySelector("#resulTerr2");

//terreno1

function areaTerreno1(){
    let larg = Number(largT1.value);
    let altu = Number(altuT1.value);
    
    let area = larg * altu;

    resultTerr1.textContent = area+"m²";
}

btTerr1.onclick = function(){
    areaTerreno1();
}

//terreno2

function terrenoArea2(){
    let larg = Number(larT2.value);
    let altu = Number(altT2.value);

    let respost = larg * altu;

    resulTerr2.textContent = respost+"m²";
}

btTrr2.onclick = function(){
    terrenoArea2();
} 